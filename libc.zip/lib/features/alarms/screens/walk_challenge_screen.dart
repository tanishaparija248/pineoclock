import 'dart:async';
import 'package:flutter/material.dart';
import 'package:pedometer/pedometer.dart';

class WalkChallengeScreen extends StatefulWidget {
  const WalkChallengeScreen({super.key});

  @override
  State<WalkChallengeScreen> createState() =>
      _WalkChallengeScreenState();
}

class _WalkChallengeScreenState extends State<WalkChallengeScreen> {
  StreamSubscription<StepCount>? _stepSubscription;

  int _initialSteps = 0;
  int _stepsWalked = 0;

  final int _targetSteps = 50;

  @override
  void initState() {
    super.initState();
    _startListening();
  }

  void _startListening() {
    _stepSubscription = Pedometer.stepCountStream.listen(
          (StepCount event) {
        if (_initialSteps == 0) {
          _initialSteps = event.steps;
        }

        setState(() {
          _stepsWalked = event.steps - _initialSteps;
        });

        if (_stepsWalked >= _targetSteps) {
          _completeChallenge();
        }
      },
      onError: (error) {
        debugPrint("Step Counter Error: $error");
      },
    );
  }

  void _completeChallenge() {
    _stepSubscription?.cancel();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text("🎉 Challenge Complete"),
        content: const Text(
          "Great job! You've completed the walk challenge.",
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text("Dismiss Alarm"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _stepSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double progress = _stepsWalked / _targetSteps;

    if (progress > 1) {
      progress = 1;
    }

    return Scaffold(
      backgroundColor: Colors.blueGrey.shade900,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.directions_walk,
                  size: 120,
                  color: Colors.white,
                ),

                const SizedBox(height: 24),

                const Text(
                  "Walk to Dismiss Alarm",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 40),

                Text(
                  "$_stepsWalked / $_targetSteps Steps",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 24),

                LinearProgressIndicator(
                  value: progress,
                  minHeight: 12,
                  borderRadius: BorderRadius.circular(20),
                ),

                const SizedBox(height: 16),

                Text(
                  "${(progress * 100).toInt()}%",
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 18,
                  ),
                ),

                const SizedBox(height: 40),

                const Text(
                  "Keep walking until you reach the target!",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}