import '../models/alarm_model.dart';

class AlarmStorage {
  static List<AlarmModel> alarms = [];
}